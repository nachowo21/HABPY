# HABPY
funcion la cual calcula la zona de habitabilidad.

para ellos se necesitan los siguientes datos de entrada que seran ingresados por el usuario:

    -la temperatura *EN KELVIN* de la estrella 
    -el radio de la estrella *EN KILOMETROS*.

finalmente el codigo entregara informacion sobre la zona de habitabilidad (los cuales seran un rango de distancias en kilometros) además de un gráfico donde se verá dicha zona *EN UNIDADES ASTRONOMICAS*

### versiones que utilizamos

version de python : 3.10 

version de matplotlib : 3.5.1

version de numpy : 1.21.5
